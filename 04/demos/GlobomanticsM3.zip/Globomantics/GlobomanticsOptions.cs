﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Globomantics
{
    public class GlobomanticsOptions
    {
        public int BoldConferenceAttendeeThreshold { get; set; }
    }
}
