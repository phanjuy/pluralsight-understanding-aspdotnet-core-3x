﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shared.Models
{
    public class StatisticsModel
    {
        public int AverageConferenceAttendees { get; set; }
        public int NumberOfAttendees { get; set; }
    }
}
